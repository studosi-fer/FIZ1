Izvodi profesora Narančića za drugi ciklus nastave Fizike 1.
Izvodi su SKUPLJENI IZ STARIJIH POSTOVA, tako da ne garantiram točnost.
Pošto nekih izvoda ili nije bilo ili su predugački, popis je nepotpun.
Izvodi koji nedostaju: 5-9, 13 i 14.
Zahvale kolegama MrShadow i starlight.

